import os
import subprocess
import sys

print("==================================================")
print("     TIM3CRAFT GraphWar Botter Installer          ")
print("==================================================")

# 1. Check Python
print("[*] Checking Python environment...")
print(f"    Python Version: {sys.version}")

# 2. Install Dependencies
print("[*] Installing required dependencies (Pillow)...")
try:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "Pillow"])
    print("[+] Dependencies installed successfully!")
except Exception as e:
    print(f"[-] Warning/Error during dependency installation: {e}")

print("\n[+] Installation complete!")
print("    You can now run 'Tim3craft_graphwar_Actuallbotter.py' to launch your bot swarm controller.")
input("Press Enter to exit...")
