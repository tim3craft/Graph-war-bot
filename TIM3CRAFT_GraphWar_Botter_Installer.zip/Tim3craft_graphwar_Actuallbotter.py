import socket
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import urllib.parse
import os

# --- NETWORK PROTOCOL CONSTANTS (Game & Global Server) ---
NET_NO_INFO = 10
NET_CHAT_MSG = 14
NET_ADD_PLAYER = 16
NET_ADD_SOLDIER = 17
NET_SET_READY = 21
NET_FIRE_FUNC = 24
NET_DISCONNECT = 39

# Global Server Protocols
GLOBAL_JOIN = 101
GLOBAL_SAY_CHAT = 102
GLOBAL_LIST_PLAYERS = 103
GLOBAL_LIST_ROOMS = 104
GLOBAL_ROOM_STATUS = 105
GLOBAL_QUIT = 106
GLOBAL_CLOSE_ROOM = 107
GLOBAL_CREATE_ROOM = 108

APP_TITLE = "TIM3CRAFT GraphWar Botter (Global Server Joiner & Swarm)"

BG = "#0e0c14"
PANEL = "#14121e"
ACCENT = "#c896ff"
PURPLE = "#783cbe"
TEXT = "#eeeeff"
MUTED = "#9990aa"

class GraphwarGlobalBot:
    def __init__(self, ip, port, name, is_global, log_callback, room_discovered_callback=None):
        self.ip = ip
        self.port = port
        self.name = name
        self.is_global = is_global
        self.log_callback = log_callback
        self.room_discovered_callback = room_discovered_callback
        self.sock = None
        self.running = False
        self.player_id = None
        self.thread = None
        self.status_text = "Idle"

    def start(self):
        self.running = True
        self.status_text = "Connecting..."
        self.thread = threading.Thread(target=self._run_loop, daemon=True)
        self.thread.start()

    def _run_loop(self):
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.settimeout(5.0)
            self.sock.connect((self.ip, self.port))
            self.status_text = "Online"
            server_type = "Global Server" if self.is_global else "Room Server"
            self.log_callback(f"[Connected] Bot '{self.name}' joined {server_type} at {self.ip}:{self.port}")

            if self.is_global:
                join_msg = f"{self.name}\n"
            else:
                join_msg = f"{NET_ADD_PLAYER}&{urllib.parse.quote(self.name)}\n"
            
            self.sock.sendall(join_msg.encode('utf-8'))
            last_keepalive = time.time()
            buffer = ""

            while self.running:
                try:
                    self.sock.settimeout(1.0)
                    data = self.sock.recv(1024)
                    if not data:
                        break
                    buffer += data.decode('utf-8', errors='ignore')
                    while "\n" in buffer:
                        line, buffer = buffer.split("\n", 1)
                        self._handle_message(line.strip())

                    if time.time() - last_keepalive > 4.0:
                        ping_code = NET_NO_INFO if not self.is_global else 10
                        self.sock.sendall(f"{ping_code}\n".encode('utf-8'))
                        last_keepalive = time.time()
                except socket.timeout:
                    if time.time() - last_keepalive > 4.0:
                        try:
                            ping_code = NET_NO_INFO if not self.is_global else 10
                            self.sock.sendall(f"{ping_code}\n".encode('utf-8'))
                            last_keepalive = time.time()
                        except Exception:
                            break
                except Exception:
                    break
        except Exception as e:
            self.status_text = "Failed"
            self.log_callback(f"[Error] Bot '{self.name}' connection failed: {e}")
        finally:
            self.stop()

    def _handle_message(self, message):
        if not message:
            return
        parts = message.split('&')
        try:
            code = int(parts[0])
            if self.is_global:
                if code == GLOBAL_LIST_ROOMS and len(parts) >= 2:
                    num_rooms = int(parts[1])
                    rooms = []
                    for i in range(num_rooms):
                        idx = 2 + (6 * i)
                        if idx + 5 < len(parts):
                            r_name = urllib.parse.unquote(parts[idx])
                            r_id = parts[idx+1]
                            r_ip = urllib.parse.unquote(parts[idx+2])
                            r_port = parts[idx+3]
                            r_mode = parts[idx+4]
                            r_players = parts[idx+5]
                            rooms.append((r_name, r_ip, r_port, r_players))
                    if self.room_discovered_callback:
                        self.room_discovered_callback(rooms)
            else:
                if code == NET_ADD_PLAYER and len(parts) >= 3:
                    if urllib.parse.unquote(parts[2]) == self.name:
                        self.player_id = int(parts[1])
        except ValueError:
            pass

    def send_ready(self, ready_state=True):
        if not self.sock or not self.running or self.is_global:
            return
        if self.player_id is not None:
            val = 1 if ready_state else 0
            msg = f"{NET_SET_READY}&{self.player_id}&{val}\n"
            try:
                self.sock.sendall(msg.encode('utf-8'))
            except Exception as e:
                self.log_callback(f"[Ready Error] {self.name}: {e}")

    def set_soldiers_count(self, target_count):
        if not self.sock or not self.running or self.is_global:
            return
        if self.player_id is not None:
            try:
                for _ in range(target_count):
                    msg = f"{NET_ADD_SOLDIER}&{self.player_id}\n"
                    self.sock.sendall(msg.encode('utf-8'))
                    time.sleep(0.05)
            except Exception as e:
                self.log_callback(f"[Soldier Error] {self.name}: {e}")

    def fire_equation(self, equation_text):
        if not self.sock or not self.running or self.is_global:
            return
        if self.player_id is not None:
            try:
                encoded_eq = urllib.parse.quote(equation_text)
                msg = f"{NET_FIRE_FUNC}&{self.player_id}&{encoded_eq}\n"
                self.sock.sendall(msg.encode('utf-8'))
            except Exception as e:
                self.log_callback(f"[Fire Error] {self.name}: {e}")

    def create_global_room(self, room_name, port_num):
        if not self.sock or not self.running or not self.is_global:
            return
        try:
            msg = f"{GLOBAL_CREATE_ROOM}&{urllib.parse.quote(room_name)}&{port_num}\n"
            self.sock.sendall(msg.encode('utf-8'))
            self.log_callback(f"[Global Room] Published room '{room_name}' on port {port_num}")
        except Exception as e:
            self.log_callback(f"[Room Create Error] {e}")

    def send_chat(self, text):
        if not self.sock or not self.running:
            return
        try:
            encoded_text = urllib.parse.quote(text)
            if self.is_global:
                msg = f"{GLOBAL_SAY_CHAT}&{encoded_text}\n"
            else:
                pid = self.player_id if self.player_id is not None else 0
                msg = f"{NET_CHAT_MSG}&{pid}&{encoded_text}\n"
            self.sock.sendall(msg.encode('utf-8'))
        except Exception as e:
            self.log_callback(f"[Chat Error] {self.name}: {e}")

    def stop(self):
        self.running = False
        self.status_text = "Offline"
        if self.sock:
            try:
                quit_code = GLOBAL_QUIT if self.is_global else NET_DISCONNECT
                self.sock.sendall(f"{quit_code}\n".encode('utf-8'))
                self.sock.close()
            except Exception:
                pass
            self.sock = None

class GraphWarBotter:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("1280x880")
        self.root.minsize(1000, 700)
        self.root.configure(bg=BG)

        self.bots = []
        self.chat_spam_active = False
        self.discovered_rooms = []
        self.is_ready_state = False

        self.build_ui()

    def button(self, parent, text, command, bg="#29213a", fg=TEXT):
        return tk.Button(parent, text=text, command=command, bg=bg, fg=fg,
                         activebackground=PURPLE, activeforeground="white",
                         relief="flat", bd=0, font=("Arial", 9, "bold"), padx=9, pady=6, cursor="hand2")

    def entry(self, parent, value):
        item = tk.Entry(parent, bg="#0d0b13", fg=TEXT, insertbackground="white", relief="flat", font=("Arial", 9))
        item.insert(0, value)
        return item

    def build_ui(self):
        header = tk.Frame(self.root, bg=BG)
        header.pack(fill="x", padx=12, pady=10)

        tk.Label(header, text="TIM3CRAFT GLOBAL SWARM JOINER", bg=BG, fg=ACCENT, font=("Arial", 16, "bold")).pack(side="left")

        main_canvas = tk.Canvas(self.root, bg=BG, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.root, orient="vertical", command=main_canvas.yview)
        
        main_layout = tk.Frame(main_canvas, bg=BG)
        main_layout.bind(
            "<Configure>",
            lambda e: main_canvas.configure(scrollregion=main_canvas.bbox("all"))
        )
        main_canvas.create_window((0, 0), window=main_layout, anchor="nw")
        main_canvas.configure(yscrollcommand=scrollbar.set)

        main_canvas.pack(side="left", fill="both", expand=True, padx=12, pady=(0, 12))
        scrollbar.pack(side="right", fill="y")

        left_ctrls = tk.Frame(main_layout, bg=BG, width=480)
        left_ctrls.pack(side="left", fill="y", padx=(0, 10), pady=5)
        left_ctrls.pack_propagate(False)

        cfg_frame = tk.LabelFrame(left_ctrls, text=" Target Server Configuration ", bg=PANEL, fg=ACCENT, font=("Arial", 10, "bold"))
        cfg_frame.pack(fill="x", padx=5, pady=5)

        tk.Label(cfg_frame, text="Server IP:", bg=PANEL, fg=MUTED).grid(row=0, column=0, padx=6, pady=6, sticky="w")
        self.bot_ip_entry = self.entry(cfg_frame, "69.164.213.144")
        self.bot_ip_entry.grid(row=0, column=1, padx=6, pady=6, sticky="ew")

        tk.Label(cfg_frame, text="Port (Global=23761):", bg=PANEL, fg=MUTED).grid(row=1, column=0, padx=6, pady=6, sticky="w")
        self.bot_port_entry = self.entry(cfg_frame, "23761")
        self.bot_port_entry.grid(row=1, column=1, padx=6, pady=6, sticky="ew")

        tk.Label(cfg_frame, text="Custom Name / Prefix:", bg=PANEL, fg=MUTED).grid(row=2, column=0, padx=6, pady=6, sticky="w")
        self.bot_prefix_entry = self.entry(cfg_frame, "Tim")
        self.bot_prefix_entry.grid(row=2, column=1, padx=6, pady=6, sticky="ew")

        tk.Label(cfg_frame, text="Bot Count:", bg=PANEL, fg=MUTED).grid(row=3, column=0, padx=6, pady=6, sticky="w")
        self.bot_count_entry = self.entry(cfg_frame, "4")
        self.bot_count_entry.grid(row=3, column=1, padx=6, pady=6, sticky="ew")

        tk.Label(cfg_frame, text="Join Delay Between Bots (s):", bg=PANEL, fg=MUTED).grid(row=4, column=0, padx=6, pady=6, sticky="w")
        self.join_delay_entry = self.entry(cfg_frame, "0.2")
        self.join_delay_entry.grid(row=4, column=1, padx=6, pady=6, sticky="ew")

        self.server_type_var = tk.StringVar(value="global")
        type_frame = tk.Frame(cfg_frame, bg=PANEL)
        type_frame.grid(row=5, column=0, columnspan=2, padx=6, pady=6, sticky="w")
        tk.Radiobutton(type_frame, text="Global Server", variable=self.server_type_var, value="global", bg=PANEL, fg=TEXT, selectcolor="#1e1a2e").pack(side="left", padx=5)
        tk.Radiobutton(type_frame, text="Room Server", variable=self.server_type_var, value="room", bg=PANEL, fg=TEXT, selectcolor="#1e1a2e").pack(side="left", padx=5)

        # --- CUSTOM CHAT & SPAMMER CONTROLS ---
        spam_frame = tk.LabelFrame(left_ctrls, text=" 💬 Custom Chat & Spammer Controls ", bg=PANEL, fg=ACCENT, font=("Arial", 10, "bold"))
        spam_frame.pack(fill="x", padx=5, pady=8)

        tk.Label(spam_frame, text="Custom Message Text:", bg=PANEL, fg=MUTED).pack(anchor="w", padx=6, pady=(4, 2))
        self.custom_chat_entry = self.entry(spam_frame, "TIM3CRAFT SWARM ACTIVE!")
        self.custom_chat_entry.pack(fill="x", padx=6, pady=2)

        chat_btn_row = tk.Frame(spam_frame, bg=PANEL)
        chat_btn_row.pack(fill="x", padx=6, pady=6)
        
        self.button(chat_btn_row, "Send Message", self.send_custom_chat_once, bg="#0284c7").pack(side="left", fill="x", expand=True, padx=(0, 3))
        self.btn_spam_toggle = self.button(chat_btn_row, "Start Chat Spammer", self.toggle_chat_spammer, bg="#3b82f6")
        self.btn_spam_toggle.pack(side="right", fill="x", expand=True, padx=(3, 0))

        act_frame = tk.LabelFrame(left_ctrls, text=" Swarm Actions & Global Room Creator ", bg=PANEL, fg=ACCENT, font=("Arial", 10, "bold"))
        act_frame.pack(fill="x", padx=5, pady=8)

        self.button(act_frame, "Spawn Swarm Bots", self.spawn_swarm_bots, bg=PURPLE).grid(row=0, column=0, padx=6, pady=6, sticky="ew")
        self.button(act_frame, "Publish Global Room", self.publish_global_room, bg="#2d5f43").grid(row=0, column=1, padx=6, pady=6, sticky="ew")

        tk.Label(act_frame, text="Soldiers per Bot:", bg=PANEL, fg=MUTED).grid(row=1, column=0, padx=6, pady=4, sticky="w")
        self.soldiers_count_entry = self.entry(act_frame, "4")
        self.soldiers_count_entry.grid(row=1, column=1, padx=6, pady=4, sticky="ew")

        self.button(act_frame, "Apply Soldiers to ALL", self.apply_soldiers_to_all, bg="#2563eb").grid(row=2, column=0, columnspan=2, padx=6, pady=6, sticky="ew")
        
        ready_row = tk.Frame(act_frame, bg=PANEL)
        ready_row.grid(row=3, column=0, columnspan=2, padx=6, pady=6, sticky="ew")
        self.btn_ready = self.button(ready_row, "Toggle Ready Up (ALL)", self.toggle_ready_all, bg="#16a34a")
        self.btn_ready.pack(side="left", fill="x", expand=True, padx=(0, 3))
        
        self.button(ready_row, "Terminate Swarm", self.terminate_swarm_bots, bg="#662222").pack(side="right", fill="x", expand=True, padx=(3, 0))

        fire_frame = tk.LabelFrame(left_ctrls, text=" Synchronized Firing & Sequencing ", bg=PANEL, fg=ACCENT, font=("Arial", 10, "bold"))
        fire_frame.pack(fill="x", padx=5, pady=8)

        tk.Label(fire_frame, text="Enter Equation (e.g., sin(x)):", bg=PANEL, fg=MUTED).pack(anchor="w", padx=6, pady=(4, 2))
        self.swarm_eq_entry = self.entry(fire_frame, "sin(x)")
        self.swarm_eq_entry.pack(fill="x", padx=6, pady=2)

        fire_btn_row = tk.Frame(fire_frame, bg=PANEL)
        fire_btn_row.pack(fill="x", padx=6, pady=6)
        self.button(fire_btn_row, "Fire All (0.1s Burst)", self.fire_all_bots_synchronized, bg="#16a34a").pack(side="left", fill="x", expand=True, padx=(0, 3))
        self.button(fire_btn_row, "Sequential Order Fire", self.fire_bots_sequentially, bg="#d97706").pack(side="right", fill="x", expand=True, padx=(3, 0))

        right_panel = tk.Frame(main_layout, bg=BG)
        right_panel.pack(side="right", fill="both", expand=True, pady=5)

        room_frame = tk.LabelFrame(right_panel, text=" Global Server Discovered Rooms Browser ", bg=PANEL, fg=ACCENT, font=("Arial", 10, "bold"))
        room_frame.pack(fill="x", padx=5, pady=5)

        room_list_container = tk.Frame(room_frame, bg=PANEL)
        room_list_container.pack(fill="x", padx=8, pady=8)

        self.room_listbox = tk.Listbox(room_list_container, bg="#0d0b13", fg=TEXT, selectbackground=PURPLE, font=("Consolas", 9), height=5)
        self.room_listbox.pack(side="left", fill="both", expand=True)
        
        room_scroll = ttk.Scrollbar(room_list_container, orient="vertical", command=self.room_listbox.yview)
        room_scroll.pack(side="right", fill="y")
        self.room_listbox.config(yscrollcommand=room_scroll.set)

        self.button(room_frame, "Connect Swarm to Selected Room IP/Port", self.connect_to_selected_room, bg="#059669").pack(fill="x", padx=8, pady=(0, 8))

        screen_frame = tk.LabelFrame(right_panel, text=" Live Bot Status Grid ", bg=PANEL, fg=ACCENT, font=("Arial", 10, "bold"))
        screen_frame.pack(fill="x", padx=5, pady=5)

        self.bot_cards_frame = tk.Frame(screen_frame, bg=PANEL)
        self.bot_cards_frame.pack(fill="x", padx=8, pady=8)
        self.build_bot_status_cards()

        log_frame = tk.LabelFrame(right_panel, text=" Swarm Activity Console ", bg=PANEL, fg=ACCENT, font=("Arial", 10, "bold"))
        log_frame.pack(fill="both", expand=True, padx=5, pady=5)

        self.swarm_log_area = scrolledtext.ScrolledText(log_frame, bg="#0d0b13", fg="#00ffcc", font=("Consolas", 9), insertbackground="white", height=12)
        self.swarm_log_area.pack(fill="both", expand=True, padx=8, pady=8)

    def build_bot_status_cards(self):
        for widget in self.bot_cards_frame.winfo_children():
            widget.destroy()

        self.bot_card_labels = []
        for i in range(10):
            row = i // 5
            col = i % 5
            card = tk.Frame(self.bot_cards_frame, bg="#1e1a2e", bd=1, relief="solid", width=110, height=55)
            card.grid(row=row, column=col, padx=4, pady=4)
            card.pack_propagate(False)

            lbl = tk.Label(card, text=f"Slot {i+1}\n[ Empty ]", bg="#1e1a2e", fg=MUTED, font=("Arial", 8, "bold"), justify="center")
            lbl.pack(fill="both", expand=True)
            self.bot_card_labels.append(lbl)

    def update_bot_status_cards(self):
        for i in range(10):
            if i < len(self.bots):
                bot = self.bots[i]
                self.bot_card_labels[i].config(text=f"{bot.name}\n[{bot.status_text}]", fg="#38ff87" if bot.running else "#ff4444")
            else:
                self.bot_card_labels[i].config(text=f"Slot {i+1}\n[ Empty ]", fg=MUTED)

    def bot_log(self, text):
        def _append():
            self.swarm_log_area.insert(tk.END, text + "\n")
            self.swarm_log_area.see(tk.END)
            self.update_bot_status_cards()
        self.root.after(0, _append)

    def on_rooms_discovered(self, rooms):
        def _update():
            self.discovered_rooms = rooms
            self.room_listbox.delete(0, tk.END)
            for r in rooms:
                display_str = f"Room: {r[0]} | IP: {r[1]} | Port: {r[2]} | Players: {r[3]}"
                self.room_listbox.insert(tk.END, display_str)
        self.root.after(0, _update)

    def spawn_swarm_bots(self):
        ip = self.bot_ip_entry.get().strip()
        try:
            port = int(self.bot_port_entry.get().strip())
            count = int(self.bot_count_entry.get().strip())
            delay = float(self.join_delay_entry.get().strip())
        except ValueError:
            self.bot_log("[Error] Port, Count, and Delay must be valid numbers.")
            return

        is_global = (self.server_type_var.get() == "global")
        name_input = self.bot_prefix_entry.get().strip()
        server_desc = "Global Server" if is_global else "Room Server"
        self.bot_log(f"[Manager] Spawning {count} bots with {delay}s delay -> {server_desc} {ip}:{port}")

        self.terminate_swarm_bots()

        def _spawn_sequence():
            for i in range(1, count + 1):
                if count == 1:
                    bot_name = name_input
                else:
                    bot_name = f"{name_input}_{i}"

                bot = GraphwarGlobalBot(ip, port, bot_name, is_global, self.bot_log, self.on_rooms_discovered)
                bot.start()
                self.bots.append(bot)
                time.sleep(delay)

        threading.Thread(target=_spawn_sequence, daemon=True).start()

    def publish_global_room(self):
        if not self.bots:
            self.bot_log("[Manager] Spawn bots on the Global Server first.")
            return
        if self.server_type_var.get() != "global":
            messagebox.showwarning("Global Server Required", "Switch target to Global Server to publish rooms.")
            return
        
        self.bot_log("[Manager] Commanding bot #1 to publish custom room on global lobby...")
        self.bots[0].create_global_room("TIM3CRAFT_Arena", 6112)

    def connect_to_selected_room(self):
        selection = self.room_listbox.curselection()
        if not selection:
            messagebox.showwarning("Selection Error", "Please select a room from the discovered rooms list.")
            return
        
        idx = selection[0]
        room_info = self.discovered_rooms[idx]
        r_ip = room_info[1]
        r_port = int(room_info[2])

        self.bot_ip_entry.delete(0, tk.END)
        self.bot_ip_entry.insert(0, r_ip)
        self.bot_port_entry.delete(0, tk.END)
        self.bot_port_entry.insert(0, str(r_port))
        self.server_type_var.set("room")

        self.bot_log(f"[Manager] Swapping target to Room Server -> {r_ip}:{r_port}. Re-spawning swarm...")
        self.spawn_swarm_bots()

    def apply_soldiers_to_all(self):
        if not self.bots:
            self.bot_log("[Soldier Error] No active bots found.")
            return
        if self.server_type_var.get() == "global":
            messagebox.showwarning("Room Server Required", "Bots must be connected to a Room Server to receive soldiers.")
            return
        try:
            target_soldiers = int(self.soldiers_count_entry.get().strip())
        except ValueError:
            self.bot_log("[Soldier Error] Invalid soldier count number.")
            return
        
        for bot in self.bots:
            threading.Thread(target=bot.set_soldiers_count, args=(target_soldiers,), daemon=True).start()

    def toggle_ready_all(self):
        if not self.bots:
            self.bot_log("[Ready Error] No active bots found.")
            return
        if self.server_type_var.get() == "global":
            messagebox.showwarning("Room Server Required", "Bots must be in a Room Server to ready up.")
            return
        
        self.is_ready_state = not self.is_ready_state
        state_str = "READY" if self.is_ready_state else "NOT READY"
        self.btn_ready.config(bg="#16a34a" if self.is_ready_state else "#d97706")
        
        for bot in self.bots:
            threading.Thread(target=bot.send_ready, args=(self.is_ready_state,), daemon=True).start()
        self.bot_log(f"[Manager] Broadcasted ready state '{state_str}' to all room bots.")

    def fire_all_bots_synchronized(self):
        if not self.bots:
            return
        eq = self.swarm_eq_entry.get().strip()
        def _fire_burst():
            threads = [threading.Thread(target=bot.fire_equation, args=(eq,), daemon=True) for bot in self.bots]
            for t in threads: t.start()
            for t in threads: t.join()
            self.bot_log(f"[Manager] Synchronized equation burst fired: '{eq}'")
        threading.Thread(target=_fire_burst, daemon=True).start()

    def fire_bots_sequentially(self):
        if not self.bots:
            return
        eq = self.swarm_eq_entry.get().strip()
        def _sequential_burst():
            for idx, bot in enumerate(self.bots, start=1):
                bot.fire_equation(eq)
                self.bot_log(f"[Sequence] Bot #{idx} ({bot.name}) fired.")
                time.sleep(0.3)
        threading.Thread(target=_sequential_burst, daemon=True).start()

    def send_custom_chat_once(self):
        if not self.bots:
            self.bot_log("[Chat Error] No active bots to send message.")
            return
        msg = self.custom_chat_entry.get().strip()
        for bot in self.bots:
            bot.send_chat(msg)
        self.bot_log(f"[Chat] Broadcasted message: '{msg}'")

    def toggle_chat_spammer(self):
        if not self.bots:
            messagebox.showwarning("Spammer Error", "Spawn bots before starting the chat spammer.")
            return
        self.chat_spam_active = not self.chat_spam_active
        if self.chat_spam_active:
            self.btn_spam_toggle.config(bg="#ef4444", text="Stop Chat Spammer")
            threading.Thread(target=self._chat_spam_loop, daemon=True).start()
            self.bot_log("[Chat] Chat spammer active loop started.")
        else:
            self.btn_spam_toggle.config(bg="#3b82f6", text="Start Chat Spammer")
            self.bot_log("[Chat] Chat spammer stopped.")

    def _chat_spam_loop(self):
        while self.chat_spam_active and self.bots:
            msg = self.custom_chat_entry.get().strip()
            for bot in self.bots:
                bot.send_chat(msg)
            time.sleep(1.0)

    def terminate_swarm_bots(self):
        self.chat_spam_active = False
        for bot in self.bots:
            bot.stop()
        self.bots.clear()
        self.update_bot_status_cards()
        self.bot_log("[Manager] All swarm bots terminated.")

if __name__ == "__main__":
    root = tk.Tk()
    app = GraphWarBotter(root)
    root.mainloop()
